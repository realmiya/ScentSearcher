CREATE TABLE target_customer
(
    index integer NOT NULL,
    customer character varying COLLATE pg_catalog."default"
);

INSERT INTO target_customer(
	index, customer)
	VALUES (0, 'for women'),
			(1, 'for men'),
			(2, 'for women and men'),
			(3, NULL)
;



CREATE TABLE perfume
(
    perfume_id serial NOT NULL primary key,
    perfume_name character varying COLLATE pg_catalog."default",
    brand character varying COLLATE pg_catalog."default",
    date integer,
    image character varying COLLATE pg_catalog."default",
    description character varying COLLATE pg_catalog."default",
    target integer
);



CREATE TABLE notes
(
    note_id serial NOT NULL primary key,
    note_name character varying COLLATE pg_catalog."default" NOT NULL
);



CREATE TABLE user_like_notes(
	account_id int references accounts(account_id),
	note_id int references notes(note_id),
	primary key (account_id,note_id)
);



CREATE TABLE user_like_perfume(
	account_id int references accounts(account_id),
	perfume_id int references perfume(perfume_id),
	primary key (account_id,perfume_id)
);



create table note_in_perfume(
	perfume_id int references perfume(perfume_id),
	note_id int references notes(note_id),
	primary key (perfume_id,note_id)
);




